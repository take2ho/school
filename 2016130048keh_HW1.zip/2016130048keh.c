#include <stdio.h>
int main() {



int a =2; 
int i;

for(i>0;i<10;i++){
printf("2*i = %d\n", a*i);


}
