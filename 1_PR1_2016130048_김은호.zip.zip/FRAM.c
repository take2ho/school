//////////////////////////////////////////////////////////////////////////
// SPI ����� �̿��� FRAM �������̽�
//   NSS(/CS) pin:  PI0 (GPIO ������� �۵�) Active LOW
//   NWP(/WP) pin:  PI4 (GPIO ������� �۵�) Active LOW
//   SCK pin:  PI1 (SPI2_SCK)
//   MOSI pin: PI2 (SPI2_MOSI)
//   MISO pin: PI3 (SPI2_MISO)
// SPI mode: MASTER
// FRAM(MB85RS64APNF, Slave mode) SRAM�� FLASH memory�� Ư¡�� ���� �޸�
//     (1byte ������ access, �����δ� 1bit�� aceess) 
//////////////////////////////////////////////////////////////////////////

#define _FRAM_RTC_C_
  #include "FRAM.h"
#undef  _FRAM_RTC_C_

#define FRAM_CS_LOW      GPIOI->ODR &= ~(1<<0); // GPIO_WriteBit(GPIOI, GPIO_Pin_0 ,0)
#define FRAM_CS_HIGH     GPIOI->ODR |=  (1<<0); // GPIO_WriteBit(GPIOI, GPIO_Pin_0 ,1) 

#define FRAM_WP_LOW      GPIOI->ODR &= ~(1<<4); // GPIO_WriteBit(GPIOI, GPIO_Pin_4 ,0)
#define FRAM_WP_HIGH     GPIOI->ODR |=  (1<<4); // GPIO_WriteBit(GPIOI, GPIO_Pin_4 ,1) 

uint8_t SPI2_Send(uint8_t byte)
{
        // Polling: Loop while DR register in not empty 
        while ((SPI2->SR & (1<<1)) == RESET);		// SR.TXE = 1 ?	
        
        // Send a byte through the SPI2 peripheral(ACC sensor)
        SPI2->DR = byte;

        // Polling: Wait to receive a byte 
        while ((SPI2->SR & (1<<0)) == RESET);		// SR.RXNE = 1 ?	
	
        // Return the byte read from the SPI bus (ACC sensor) 
        return(SPI2->DR);
}

///////////////////////////////////////////////////////
// SPI2 (APB1ENR.14) 
// Msater mode, Full-duplex, 8bit frame(MSB first), 
// fPCLK/32 Baud rate, Software slave management EN
void FRAM_Init(void)  
{
	SPI_InitTypeDef  SPI_InitStructure;

	/*!< Clock Enable  *********************************************************/
        RCC->APB1ENR 	|= (1<<14);	// SPI2 Clock EN
        RCC->AHB1ENR 	|= (1<<8);	// GPIOI Clock EN		
  
        /*!< SPI2 pins configuration ************************************************/
	
        /*!< SPI2 NSS pin(PI4) configuration : GPIO ��  */
        GPIOI->MODER 	|= (1<<(2*4));	// PI4 Output mode
        GPIOI->OTYPER 	&= ~(1<<4); 	// PI4 push-pull(reset state)
        GPIOI->OSPEEDR 	|= (2<<(2*4));	// PI4 Output speed (50MHZ) 
        GPIOI->PUPDR 	&= ~(3<<(2*4));	// PI4 NO Pullup Pulldown(reset state)

        /*!< SPI2 NWP pin(PI0) configuration : GPIO ��  */
        GPIOI->MODER 	|= (1<<(2*0));	// PI0 Output mode
        GPIOI->OTYPER 	&= ~(1<<0); 	// PI0 push-pull(reset state)
        GPIOI->OSPEEDR 	|= (2<<(2*0));	// PI0 Output speed (50MHZ) 
        GPIOI->PUPDR 	&= ~(3<<(2*0));	// PI0 NO Pullup Pulldown(reset state)
    
        /*!< SPI2 SCK pin(PI1) configuration : SPI2_SCK */
        GPIOI->MODER 	|= (2<<(2*1)); 	// PI1 Alternate function mode
        GPIOI->OTYPER 	&= ~(1<<1); 	// PI1 Output type push-pull (reset state)
        GPIOI->OSPEEDR 	|= (2<<(2*1));	// PI1 Output speed (50MHz)
        GPIOI->PUPDR 	|= (2<<(2*1)); 	// PI1 Pull-down
        GPIOI->AFR[0] 	|= (5<<(4*1));	// Connect PI1 to AF5(SPI2)
    
        /*!< SPI2 MOSI pin(PI2) configuration : SPI2_MOSI */    
        GPIOI->MODER 	|= (2<<(2*2));	// PI2 Alternate function mode
        GPIOI->OTYPER	&= ~(1<<2);	// PI2 Output type push-pull (reset state)
        GPIOI->OSPEEDR 	|= (2<<(2*2));	// PI2 Output speed (50MHz)
        GPIOI->PUPDR 	|= (2<<(2*2)); 	// PI2 Pull-down
        GPIOI->AFR[0] 	|= (5<<(4*2));	// Connect PI2 to AF5(SPI2)
    
        /*!< SPI2 MISO pin(PI3) configuration : SPI2_MISO */
        GPIOI->MODER 	|= (2<<(2*3));	// PI3 Alternate function mode
        GPIOI->OTYPER 	&= ~(1<<3);	// PI3 Output type push-pull (reset state)
        GPIOI->OSPEEDR 	|= (2<<(2*3));	// PI3 Output speed (50MHz)
        GPIOI->PUPDR 	|= (2<<(2*3));	// PI3 Pull-down
        GPIOI->AFR[0] 	|= (5<<(4*3));	// Connect PI3 to AF5(SPI2)

        // Init SPI2 Registers 
	

        SPI2->CR1 |= (1<<2);	// MSTR(Master selection)=1, Master mode
        SPI2->CR1 &= ~(1<<15);	// SPI_Direction_2 Lines_FullDuplex
        SPI2->CR1 &= ~(1<<11);	// SPI_DataSize_8bit
        SPI2->CR1 |= (1<<9);  	// SSM(Software slave management)=1, 
				// NSS �� ���°� �ڵ��� ���� ����
        SPI2->CR1 |= (1<<8);   	// SSI(Internal_slave_select)=1,
				// ���� MCU�� Master�� �̹Ƿ� NSS ���´� 'High' 
        SPI2->CR1 &= ~(1<<7);	// LSBFirst=0, MSB transmitted first    
        SPI2->CR1 |= (4<<3);	// BR(BaudRate)=0b100, fPCLK/32 (84MHz/32 = 2.625MHz)
        SPI2->CR1 |= (1<<1);	// CPOL(Clock polarity)=1, CK is 'High' when idle
        SPI2->CR1 |= (1<<0);	// CPHA(Clock phase)=1, �� ��° edge ���� �����Ͱ� ���ø�

        SPI2->CR1 |= (1<<6);	// SPE=1, SPI2 Enable 
}

void Fram_Latch(char command)
{
	FRAM_CS_LOW;
	SPI2_Send(command);
	FRAM_CS_HIGH; 
}

void Fram_Status_Config(void)
{
	uint8_t WriteBuf = 0x00;
	uint8_t data = 0;
	uint8_t read_data = 0;
	char command = WRSR;
  
	FRAM_WP_HIGH;  
    
	FRAM_CS_LOW;
	SPI2_Send(command);
	SPI2_Send(WriteBuf);
	FRAM_CS_HIGH;
 
	data = RDSR;
 
	FRAM_CS_LOW;
	SPI2_Send(data);
	read_data = SPI2_Send(0xff);
	FRAM_CS_HIGH;
}

void Fram_Write(short addr,unsigned char data)
{
	uint8_t Data[4];
	const uint16_t TIMEOUT = 5000;
  
	Fram_Latch(WREN);
  
	Data[0] = WRITE;
	Data[1] = addr>>8;
	Data[2] = addr&0xff;
	Data[3] = data;
  
	FRAM_CS_LOW;
	SPI2_Send(Data[0]);
	SPI2_Send(Data[1]);
	SPI2_Send(Data[2]);
	SPI2_Send(Data[3]);
	FRAM_CS_HIGH;
}

unsigned char Fram_Read(short addr)
{
	uint8_t data[3],read_data; 
	const uint16_t TIMEOUT = 5000;
	Fram_Latch(WRDI);
  
	data[0] = READ;
	data[1] = addr>>8;
	data[2] = addr&0xff;
  
	FRAM_CS_LOW;
	SPI2_Send(data[0]);
	SPI2_Send(data[1]);
	SPI2_Send(data[2]);
	read_data = SPI2_Send(0xff);
	FRAM_CS_HIGH;
  
	return read_data;
}


